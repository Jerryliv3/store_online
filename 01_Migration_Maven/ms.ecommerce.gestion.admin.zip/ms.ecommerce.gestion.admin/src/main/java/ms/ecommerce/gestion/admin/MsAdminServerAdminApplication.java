package ms.ecommerce.gestion.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAdminServerAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAdminServerAdminApplication.class, args);
	}

}
