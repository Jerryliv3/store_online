package ms.ecommerce.ventas.usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsEcommerceVentasUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
