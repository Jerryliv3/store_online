package ms.ecommerce.ventas.usuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsEcommerceVentasUsuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsEcommerceVentasUsuariosApplication.class, args);
	}

}
